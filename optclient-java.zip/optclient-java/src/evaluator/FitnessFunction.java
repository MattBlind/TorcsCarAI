package evaluator;


public interface FitnessFunction {

	  public Object getFitness(double bestlap,double topspeed, double distraced, double damage);
}
